Saathvik Chandupatla

I worked on implementing all the functions of both milestones. I ran into some difficulties in the rotate functions and couldn't get
those sorted out in time for submission, but all other programs should be working. I wrote additional tests to test edge cases and negatives
for all the functions except for rotate since I couldn't get those to work in the first place.
